#!/usr/bin/env bash
set -euo pipefail

git init
git add .
git commit -m "Initialize NAG Difference hopfion benchmark"
gh repo create richman954/nag-difference-hopfion \
  --public \
  --description "NAG Difference benchmark for laser-written FeGe hopfion state selection" \
  --source=. \
  --remote=origin \
  --push
