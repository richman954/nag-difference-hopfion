from nagdiff.scoring import nag_difference


def test_barrier_only_merge_beats_collapse():
    d = nag_difference(barrier_i=2.24e-4, barrier_j=2.86e-4)
    assert d < 0


def test_barrier_only_escape_loses_to_collapse():
    d = nag_difference(barrier_i=7.32e-4, barrier_j=2.86e-4)
    assert d > 0
