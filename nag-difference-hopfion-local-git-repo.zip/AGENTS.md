# AGENTS.md

## Project goal

Build a reproducible NAG Difference benchmark around laser-written magnetic
hopfions in FeGe.

## Coding rules

- Keep raw files under `data/raw/`.
- Write generated files under `data/processed/`.
- Do not hard-code final scientific claims without source metadata.
- Preserve `extraction_status` fields until raw MOESM sheets are verified.
- Keep Blender scripts under `blender/`.
- Keep mathematical scoring code under `nagdiff/`.

## First priority tasks

1. Verify the seeded MEP barriers by parsing MOESM13/MOESM16.
2. Add exact source sheet/cell/range metadata for each numeric row.
3. Extract probability rows from MOESM11.
4. Extract collapse/stability rows from MOESM12.
5. Extract observable mismatch/residual profiles from MOESM10/MOESM15.
6. Feed verified JSON into the Blender `PulseMask` visualizer.
