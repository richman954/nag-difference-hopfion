# NAG Difference in a Laser-Driven Topological Energy Landscape

## Thesis

The FeGe hopfion benchmark can be used as a physical case study for
difference-based state selection. The experimental system contains several
candidate endpoints or metastable textures: helix/cone background, skyrmions,
antiskyrmions, skyrmion-antiskyrmion pairs, hopfions, bobber-like states, and
composite textures. The useful selection object is not a single absolute
trajectory. It is a pairwise endpoint certificate.

## Core certificate

For two candidate endpoints or transition paths `i` and `j`, use

```text
D_i_j(lambda)
= [Delta E_i^‡(lambda)-Delta E_j^‡(lambda)]
+ alpha[epsilon_i(lambda)-epsilon_j(lambda)]
- beta[log(P_i(lambda)+delta)-log(P_j(lambda)+delta)]
+ gamma[tau_i-tau_j].
```

Candidate `i` beats candidate `j` when `D_i_j(lambda)<0`.

## v0 seeded barrier result

The seeded MEP rows give:

```text
Delta E_merge   = 2.24e-4 pJ
Delta E_collapse= 2.86e-4 pJ
Delta E_escape  = 7.32e-4 pJ
```

Therefore:

```text
Delta E_merge < Delta E_collapse < Delta E_escape.
```

The NAG-Difference interpretation is that the skyrmion-antiskyrmion merger
route has the lower transition certificate relative to competing loss paths.
That makes it the first clean benchmark inequality for the project.

## Evidence layers to add after raw extraction

1. Control thresholds from MOESM9/MOESM14.
2. Nucleation probabilities from MOESM11.
3. Stability/collapse fields from MOESM12.
4. Observable residuals from MOESM10/MOESM15.
5. Topological-sector labels and penalties from the paper's Hopf classification.

## Blender use

Each endpoint or transition path can become a visual channel. The current
waveguide script can map the barrier-derived certificate into its `PulseMask`
attribute so that lower-difference channels are brighter.
