# NAG Difference Hopfion Benchmark

This is a repo-ready benchmark pack for the NAG Difference project.

## Concept

The benchmark treats the laser-written FeGe hopfion experiment as a physical
case study for difference-based state selection. Instead of assigning meaning
to one raw trajectory, it compares candidate endpoints or transition paths:

```text
D_i_j(lambda)
= [Delta E_i^‡(lambda)-Delta E_j^‡(lambda)]
+ alpha[epsilon_i(lambda)-epsilon_j(lambda)]
- beta[log(P_i(lambda)+delta)-log(P_j(lambda)+delta)]
+ gamma[tau_i-tau_j]
```

Candidate `i` beats candidate `j` when `D_i_j(lambda) < 0`.

## Current v0 status

The processed files are seeded from the prior project notes. The raw MOESM
Excel files were not present in this execution workspace, so exact spreadsheet
extraction is pending. The first seeded inequality is:

```text
Delta E_merge < Delta E_collapse < Delta E_escape
```

Seeded values:

| Transition path | Barrier pJ |
|---|---:|
| skyrmion-antiskyrmion merge -> hopfion | 2.24e-4 |
| hopfion collapse | 2.86e-4 |
| hopfion escape | 7.32e-4 |

## Main outputs

```text
data/processed/nag_hopfion_master_matrix.csv
data/processed/nag_hopfion_pairwise_barriers.csv
data/processed/nag_hopfion_scoring_template.csv
data/processed/nag_hopfion_barriers_for_blender.json
notebooks/01_build_master_matrix.ipynb
nagdiff/scoring.py
nagdiff/pairwise.py
figures/barrier_selection_diagram.png
```

## Next raw-data step

Place the raw supplementary Excel files in `data/raw/`, especially:

```text
41567 2026 3236 MOESM13*
41567 2026 3236 MOESM16*
```

Then run:

```bash
python -m pip install -e .
jupyter lab notebooks/01_build_master_matrix.ipynb
```

or run the extraction cells manually.


## GitHub-ready setup

This repository includes:

```text
.github/workflows/tests.yml  # pytest CI
scripts/push_to_github.sh    # optional GitHub CLI push helper
docs/GITHUB_IMPORT.md        # manual and bundle import instructions
```

Run tests locally:

```bash
python -m pip install -e . pytest
pytest -q
```

Push with GitHub CLI:

```bash
./scripts/push_to_github.sh richman954/nag-difference-hopfion --public
```

## Blender connection

The JSON file in `data/processed/` is structured so the uploaded waveguide
script can treat each transition path as a channel/bar and drive pulse
brightness using the seeded barrier-derived `pulse_mask_suggested`.

## GitHub/Codex workflow

After creating a GitHub repo, push this directory with:

```bash
./scripts/push_to_github.sh https://github.com/richman954/nag-difference-hopfion.git main
```

Then open the repository in Codex and use `docs/CODEX_NEXT_PROMPT.md` to convert the seeded v0 values into verified MOESM-derived v1 values.

## GitHub/Codex path

The recommended repository is:

```text
richman954/nag-difference-hopfion
```

Use `GITHUB_SETUP.md` to push the project and `CODEX_TASKS.md` to start the first Codex pass. The included GitHub Actions workflow runs the Python tests on every push and pull request.
