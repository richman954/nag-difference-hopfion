# Raw supplementary files

Place the raw FeGe hopfion supplementary files here before rerunning extraction notebooks.

Expected priority inputs:

```text
41567 2026 3236 MOESM13*
41567 2026 3236 MOESM16*
```

Useful follow-on inputs:

```text
41567 2026 3236 MOESM9*
41567 2026 3236 MOESM10*
41567 2026 3236 MOESM11*
41567 2026 3236 MOESM12*
41567 2026 3236 MOESM14*
41567 2026 3236 MOESM15*
```

Raw publication PDFs and supplementary spreadsheets are intentionally not committed by default. Keep them local unless redistribution rights are clear.
