# Extraction status

This v0 benchmark pack contains the first NAG-Difference evidence matrix.

Status:
- MOESM13/MOESM16 barrier rows are seeded from the prior conversation notes.
- Values are approximate and marked `raw_moesm_verification_pending`.
- Raw MOESM Excel files are not present in this execution workspace, so the notebook is built to re-run extraction once those files are placed in `data/raw/`.

Seeded barrier values:
- skyrmion-antiskyrmion merge -> hopfion: 2.24e-4 pJ
- hopfion collapse: 2.86e-4 pJ
- hopfion escape: 7.32e-4 pJ

Primary NAG-Difference inequality:
`Delta E_merge < Delta E_collapse < Delta E_escape`

DOI/source URL used in the matrix:
https://doi.org/10.1038/s41567-026-03236-0
