# GitHub setup

Recommended repository name:

```text
richman954/nag-difference-hopfion
```

## Option A: GitHub CLI

From inside this folder:

```bash
git init
git add .
git commit -m "Initialize NAG Difference hopfion benchmark"

gh repo create richman954/nag-difference-hopfion \
  --public \
  --description "NAG Difference benchmark for laser-written FeGe hopfion state selection" \
  --source=. \
  --remote=origin \
  --push
```

## Option B: use the existing empty repository

The connected GitHub account currently exposes `richman954/hello-world` and `richman954/ShadowMap-QEC`. The `hello-world` repository is empty and can be repurposed, but a new repo is cleaner.

To repurpose `hello-world`:

```bash
git init
git add .
git commit -m "Initialize NAG Difference hopfion benchmark"
git branch -M master
git remote add origin https://github.com/richman954/hello-world.git
git push -u origin master
```

## Option C: GitHub web upload

1. Create a new public or private repository named `nag-difference-hopfion`.
2. Upload the contents of this folder.
3. Confirm the CI workflow appears under `.github/workflows/ci.yml`.
4. Check that `python -m pytest -q` passes in GitHub Actions.

## Codex starter prompt

```text
This repository is the NAG Difference Hopfion Benchmark.

First task:
- Verify the processed barrier-only seed table.
- Add a loader for raw MOESM13/MOESM16 Excel files under data/raw/.
- Replace seeded barrier values with spreadsheet-extracted values when raw files are present.
- Preserve explicit extraction provenance: source_file, sheet, row, column, unit, notes.
- Keep tests passing.
- Do not remove the seeded fallback values until raw extraction succeeds.
```
