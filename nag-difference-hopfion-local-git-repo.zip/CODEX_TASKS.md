# Codex task plan

## Task 1: raw MEP extraction

Add robust extraction for MOESM13/MOESM16 and update `notebooks/01_build_master_matrix.ipynb` so it can either:

1. use raw spreadsheet values when available, or
2. fall back to the current seeded values with `verification_status = seeded_from_prior_notes__raw_moesm_verification_pending`.

## Task 2: pairwise selector tests

Add tests for:

- anti-symmetry: `D_i_j = -D_j_i` for matched terms,
- barrier-only selection,
- probability term direction,
- tie reporting in `select_by_pairwise_record`.

## Task 3: Blender bridge

Create `blender/NAG_Difference_Endpoint_Visualizer.py` that reads:

```text
data/processed/nag_hopfion_barriers_for_blender.json
```

and uses each transition path as a visual channel. The existing waveguide script already has a named `PulseMask` emission hook, so the new script should make the mask data-driven rather than only periodic.
