# Repository plan

## Immediate objective

Make the FeGe hopfion package a reproducible case study for NAG-Difference-style endpoint/state selection.

## Current state

The repository contains a seeded barrier-only benchmark for three transition paths:

```text
skyrmion-antiskyrmion merge -> hopfion
hopfion collapse
hopfion escape
```

The first working inequality is:

```text
Delta E_merge < Delta E_collapse < Delta E_escape
```

## Why this is GitHub-ready

- Python package scaffold under `nagdiff/`
- CI workflow under `.github/workflows/ci.yml`
- Tests under `tests/`
- Processed CSV/JSON outputs under `data/processed/`
- Raw-data placeholder under `data/raw/`
- Blender bridge under `blender/`
- Theory memo and project README at repository root

## Next PR

The first PR should verify MOESM13/MOESM16 extraction and replace seeded values with raw-sheet provenance.
