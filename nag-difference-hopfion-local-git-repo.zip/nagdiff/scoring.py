"""Scoring utilities for NAG Difference endpoint comparisons.

The core object is the pairwise certificate

    D_i_j = w_barrier*(barrier_i-barrier_j)
          + w_observable*(epsilon_i-epsilon_j)
          - w_probability*(log(P_i+delta)-log(P_j+delta))
          + w_topology*(tau_i-tau_j)

Candidate i beats candidate j when D_i_j < 0.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import log
from typing import Optional


@dataclass(frozen=True)
class Weights:
    """Weights for the NAG Difference certificate."""

    barrier: float = 1.0
    observable: float = 1.0
    probability: float = 1.0
    topology: float = 1.0
    delta: float = 1.0e-12


def _zero_if_none(value: Optional[float]) -> float:
    """Return 0.0 for missing additive terms."""
    return 0.0 if value is None else float(value)


def _probability_or_default(value: Optional[float], default: float) -> float:
    """Return a safe probability-like value for log terms."""
    if value is None:
        return default
    return float(value)


def nag_difference(
    *,
    barrier_i: Optional[float] = None,
    barrier_j: Optional[float] = None,
    observable_i: Optional[float] = None,
    observable_j: Optional[float] = None,
    probability_i: Optional[float] = None,
    probability_j: Optional[float] = None,
    topology_i: Optional[float] = None,
    topology_j: Optional[float] = None,
    weights: Weights = Weights(),
) -> float:
    """Compute D_i_j for two endpoints or transition paths.

    Negative values mean endpoint/path i is preferred to endpoint/path j.
    Missing additive terms are treated as zero. Missing probabilities are
    treated as 1.0 so the probability term vanishes until data are available.
    """

    b_i = _zero_if_none(barrier_i)
    b_j = _zero_if_none(barrier_j)
    e_i = _zero_if_none(observable_i)
    e_j = _zero_if_none(observable_j)
    t_i = _zero_if_none(topology_i)
    t_j = _zero_if_none(topology_j)

    p_i = _probability_or_default(probability_i, 1.0)
    p_j = _probability_or_default(probability_j, 1.0)

    return (
        weights.barrier * (b_i - b_j)
        + weights.observable * (e_i - e_j)
        - weights.probability * (log(p_i + weights.delta) - log(p_j + weights.delta))
        + weights.topology * (t_i - t_j)
    )


def pairwise_certificate(candidate_i: dict, candidate_j: dict, weights: Weights = Weights()) -> float:
    """Compute D_i_j from two candidate dictionaries.

    Accepted keys:
    - barrier_pJ
    - observable_mismatch
    - nucleation_probability
    - topology_penalty
    """

    return nag_difference(
        barrier_i=candidate_i.get("barrier_pJ"),
        barrier_j=candidate_j.get("barrier_pJ"),
        observable_i=candidate_i.get("observable_mismatch"),
        observable_j=candidate_j.get("observable_mismatch"),
        probability_i=candidate_i.get("nucleation_probability"),
        probability_j=candidate_j.get("nucleation_probability"),
        topology_i=candidate_i.get("topology_penalty"),
        topology_j=candidate_j.get("topology_penalty"),
        weights=weights,
    )
