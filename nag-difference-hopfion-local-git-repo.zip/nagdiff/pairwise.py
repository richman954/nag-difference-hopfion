"""Pairwise tables and winner selection for NAG Difference benchmarks."""

from __future__ import annotations

from itertools import combinations
from typing import Iterable, Mapping

from .scoring import Weights, pairwise_certificate


def pairwise_barrier_table(items: Iterable[Mapping]) -> list[dict]:
    """Build a barrier-only pairwise table.

    Each item should contain:
    - transition_id
    - transition_label
    - barrier_pJ
    """

    normalized = [dict(item) for item in items]
    rows: list[dict] = []

    for item_i, item_j in combinations(normalized, 2):
        barrier_i = float(item_i["barrier_pJ"])
        barrier_j = float(item_j["barrier_pJ"])
        d_i_j = barrier_i - barrier_j
        preferred = item_i if d_i_j < 0 else item_j

        rows.append(
            {
                "comparison_id": f"{item_i['transition_id']}__minus__{item_j['transition_id']}",
                "transition_i": item_i["transition_label"],
                "transition_j": item_j["transition_label"],
                "barrier_i_pJ": barrier_i,
                "barrier_j_pJ": barrier_j,
                "D_i_j_pJ": d_i_j,
                "preferred_transition": preferred["transition_label"],
            }
        )

    return rows


def select_by_pairwise_record(candidates: Iterable[Mapping], weights: Weights = Weights()) -> dict:
    """Select the candidate with the best pairwise win record.

    Returns a dictionary with the selected candidate, all pairwise comparisons,
    and the win counts. Ties are returned explicitly instead of hidden.
    """

    normalized = [dict(candidate) for candidate in candidates]
    if not normalized:
        raise ValueError("At least one candidate is required.")

    win_counts = {candidate["id"]: 0 for candidate in normalized}
    comparisons: list[dict] = []

    for candidate_i, candidate_j in combinations(normalized, 2):
        d_i_j = pairwise_certificate(candidate_i, candidate_j, weights=weights)
        winner = candidate_i if d_i_j < 0 else candidate_j
        win_counts[winner["id"]] += 1
        comparisons.append(
            {
                "candidate_i": candidate_i["id"],
                "candidate_j": candidate_j["id"],
                "D_i_j": d_i_j,
                "winner": winner["id"],
            }
        )

    max_wins = max(win_counts.values())
    winners = [candidate_id for candidate_id, count in win_counts.items() if count == max_wins]

    return {
        "winner_ids": winners,
        "is_tie": len(winners) > 1,
        "win_counts": win_counts,
        "comparisons": comparisons,
    }
